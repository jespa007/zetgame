#ifndef XMP_ASIF_H
#define XMP_ASIF_H

#include <stdio.h>
#include "common.h"
#include "hio.h"

int asif_load(struct module_data *, HIO_HANDLE *, int);

#endif
