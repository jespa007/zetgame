#ifndef LIBXMP_OS2_UNISTD_H
#define LIBXMP_OS2_UNISTD_H

#include <io.h>  /* do not want Watcom unistd.h */

#endif
